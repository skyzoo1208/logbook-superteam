// Contoh data dari database (bisa diganti dengan API)
const dataDariDatabase = {
    logbook: 160,
    divisi: 11,
    user: 43
};

// Menampilkan angka dari database ke dalam elemen HTML
document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("logbook-count").textContent = dataDariDatabase.logbook;
    
    document.getElementById("user-count").textContent = dataDariDatabase.user;
});

// Jika ingin mengambil data dari API (contoh fetch ke backend)
fetch("https://example.com/api/dashboard-data") // Ganti dengan URL API-mu
    .then(response => response.json())
    .then(data => {
        document.getElementById("logbook-count").textContent = data.logbook;
        
        document.getElementById("user-count").textContent = data.user;
    })
    .catch(error => console.error("Error fetching data:", error));
