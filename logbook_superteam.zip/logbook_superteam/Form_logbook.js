window.onscroll = function () {
    const header = document.querySelector("header");
    const fixedNav = header.offsetTop;

    if (window.pageYOffset > fixedNav) {
        header.classList.add("navbar-fixed");
    } else {
        header.classList.remove("navbar-fixed");
    }
};

document.addEventListener("DOMContentLoaded", function () {
    let today = new Date();
    let dayIndex = today.getDay(); // 0 = Minggu, 1 = Senin, ..., 5 = Jumat, 6 = Sabtu

    let days = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
    let todayName = days[dayIndex].toUpperCase(); // Sesuaikan dengan teks tombol (huruf besar semua)

    console.log("Hari ini adalah:", todayName); // Debugging: pastikan hari yang terdeteksi benar

    document.querySelectorAll(".hari-btn").forEach(button => {
        if (button.innerText !== todayName) {
            button.disabled = true; // Nonaktifkan tombol selain hari ini
            button.style.opacity = "0.5"; // Buat tombol tampak tidak aktif
            button.style.cursor = "not-allowed";
        }
    });
});

function pilihHari(hari) {
    localStorage.setItem("hariTerpilih", hari);
    window.location.href = "hari.html"; // Pindah ke halaman pengisian logbook
};


document.addEventListener("DOMContentLoaded", function () {
    // Ambil parameter minggu dari URL
    const params = new URLSearchParams(window.location.search);
    const minggu = params.get("minggu");

    if (minggu) {
        document.querySelector("h2").innerText = `Minggu ke-${minggu}`;
    } else {
        document.querySelector("h2").innerText = "Minggu tidak diketahui";
    }
});

