window.onscroll = function () {
    const header = document.querySelector("header");
    const fixedNav = header.offsetTop;

    if (window.pageYOffset > fixedNav) {
        header.classList.add("navbar-fixed");
    } else {
        header.classList.remove("navbar-fixed");
    }
};

// fitur akses mingguan

document.addEventListener("DOMContentLoaded", function () {
    console.log("JavaScript berhasil dijalankan!");

    
    let today = new Date();
    let todayStr = today.toISOString().split("T")[0]; // Format YYYY-MM-DD
    console.log("Tanggal Hari Ini:", todayStr);

    // Data minggu yang diperbolehkan
    const allowedWeeks = {
        "Minggu ke-5": { start: "2025-03-17", end: "2025-03-21" },
        "Minggu ke-6": { start: "2025-03-24", end: "2025-03-28" },
        "Minggu ke-7": { start: "2025-03-31", end: "2025-04-04" },
        "Minggu ke-8": { start: "2025-04-07", end: "2025-04-11" },
        "Minggu ke-9": { start: "2025-04-14", end: "2025-04-18" },
        "Minggu ke-10": { start: "2025-04-21", end: "2025-04-25" },
        "Minggu ke-11": { start: "2025-05-05", end: "2025-05-09" },
        "Minggu ke-12": { start: "2025-05-12", end: "2025-05-16" },
        "Minggu ke-13": { start: "2025-05-18", end: "2025-05-23" },
        "Minggu ke-14": { start: "2025-05-26", end: "2025-05-30" },       
    };

    document.querySelectorAll(".week-item").forEach((weekItem) => {
        let weekName = weekItem.getAttribute("data-week");
        let weekData = allowedWeeks[weekName];

        if (weekData) {
            let startDate = new Date(weekData.start);
            let endDate = new Date(weekData.end);

            let startDateStr = startDate.toISOString().split("T")[0];
            let endDateStr = endDate.toISOString().split("T")[0];

            console.log(`Mengecek: ${weekName}`);
            console.log(`Rentang Waktu: ${startDateStr} - ${endDateStr}`);

            if (todayStr >= startDateStr && todayStr <= endDateStr) {
                console.log(`${weekName} AKTIF`);
                weekItem.classList.remove("opacity-50", "pointer-events-none");
            } else {
                console.log(`${weekName} TERKUNCI`);
                weekItem.classList.add("opacity-50", "pointer-events-none");

                // Mencegah klik jika minggu tidak aktif
                weekItem.addEventListener("click", function (event) {
                    event.preventDefault();
                    alert("Minggu ini belum dapat dibuka!");
                });
            }
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {
    console.log("JavaScript berhasil dijalankan!");

    let today = new Date();
    let todayStr = today.toISOString().split("T")[0]; // Format YYYY-MM-DD
    console.log("Tanggal Hari Ini:", todayStr);

    // Data minggu yang diperbolehkan
    const allowedWeeks = {
        "Minggu ke-5": { start: "2025-03-17", end: "2025-03-21" },
        "Minggu ke-6": { start: "2025-03-24", end: "2025-03-28" },
        "Minggu ke-7": { start: "2025-03-31", end: "2025-04-04" },
        "Minggu ke-8": { start: "2025-04-07", end: "2025-04-11" },
        "Minggu ke-9": { start: "2025-04-14", end: "2025-04-18" },
        "Minggu ke-10": { start: "2025-04-21", end: "2025-04-25" },
        "Minggu ke-11": { start: "2025-05-05", end: "2025-05-09" },
        "Minggu ke-12": { start: "2025-05-12", end: "2025-05-16" },
        "Minggu ke-13": { start: "2025-05-18", end: "2025-05-23" },
        "Minggu ke-14": { start: "2025-05-26", end: "2025-05-30" },       
    };

    document.querySelectorAll(".week-item").forEach((weekItem) => {
        let weekName = weekItem.getAttribute("data-week");
        let weekData = allowedWeeks[weekName];

        if (weekData) {
            let startDate = new Date(weekData.start);
            let endDate = new Date(weekData.end);

            let startDateStr = startDate.toISOString().split("T")[0];
            let endDateStr = endDate.toISOString().split("T")[0];

            let icon = weekItem.querySelector("img"); // Ambil elemen gambar dalam setiap box

            console.log(`Mengecek: ${weekName}`);
            console.log(`Rentang Waktu: ${startDateStr} - ${endDateStr}`);

            if (todayStr > endDateStr) {
                // Jika minggu sudah berlalu, ubah ke FileCeklis
                icon.src = "img/FileCeklis.png";
            } else if (todayStr >= startDateStr && todayStr <= endDateStr) {
                // Jika minggu sedang berlangsung, ubah ke FileTulis
                icon.src = "img/FileTulis.png";
            } else {
                // Jika minggu masih di masa depan, ubah ke FileKunci
                icon.src = "img/FileKunci.png";
            }
        }
    });
});



console.log(`Hari ini: ${todayStr}`);
console.log(`Mengecek: ${weekName}`);
console.log(`Rentang Waktu: ${startDateStr} - ${endDateStr}`);
