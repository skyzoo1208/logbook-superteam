document.addEventListener("DOMContentLoaded", function () {
    fetch("get_logbook.php") // Ambil data dari backend
        .then(response => {
            if (!response.ok) {
                throw new Error("Gagal mengambil data"); // Cegah error jika respons bukan 200 OK
            }
            return response.json();
        })
        .then(data => {
            let tbody = document.querySelector("tbody");
            if (!tbody) {
                console.error("Tabel tidak ditemukan!");
                return;
            }
            tbody.innerHTML = ""; // Hapus isi tabel sebelum ditambahkan data baru

            data.forEach((logbook, index) => {
                let row = document.createElement("tr");
                row.innerHTML = `
                    <td class="border border-slate-700">${index + 1}</td>
                    <td class="border border-slate-700">${logbook.nama_logbook}</td>
                    <td class="border border-slate-700">${logbook.nama}</td>
                    <td class="border border-slate-700">${logbook.waktu_pengumpulan}</td>
                `;
                tbody.appendChild(row); // Gunakan appendChild agar performa lebih baik
            });
        })
        .catch(error => console.error("Error mengambil logbook:", error));
});
