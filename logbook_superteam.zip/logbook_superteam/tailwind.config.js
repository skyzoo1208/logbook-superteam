
module.exports = {
  content: ['homepage.html','logbook.html','history.html','Form_logbook.html','hari.html','Profile.html','jumlah_logbook.html','dashboard.html','jumlah_divisi.html','jumlah_user.html'
    ,'register_akun.html'],
  theme: {
    extend: {},
  },
  plugins: [],
};

