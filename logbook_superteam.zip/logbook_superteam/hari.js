window.onscroll = function(){
    const header = document.querySelector('header');
    const fixedNav = header.offsetTop;

    if(window.pageYOffset > fixedNav) {
        header.classList.add('navbar-fixed');
    } else {
        header.classList.remove('navbar-fixed');

    }
};

document.addEventListener("DOMContentLoaded", function () {
    let inputTanggal = document.getElementById("hari-tanggal");

    let today = new Date();
    let dayIndex = today.getDay(); // 0 = Minggu, ..., 6 = Sabtu
    let days = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
    let todayName = days[dayIndex];

    let tanggal = String(today.getDate()).padStart(2, '0');
    let bulan = String(today.getMonth() + 1).padStart(2, '0');
    let tahun = today.getFullYear();

    let tanggalHariIni = `${todayName}, ${tanggal}-${bulan}-${tahun}`;
    inputTanggal.value = tanggalHariIni;
});

